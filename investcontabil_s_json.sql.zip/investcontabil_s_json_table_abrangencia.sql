
-- --------------------------------------------------------

--
-- Estrutura da tabela `abrangencia`
--

CREATE TABLE `abrangencia` (
  `abrangencia_id` int(11) NOT NULL,
  `sigla_abrangencia` varchar(3) NOT NULL,
  `descricao` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `abrangencia`
--

INSERT INTO `abrangencia` (`abrangencia_id`, `sigla_abrangencia`, `descricao`) VALUES
(1, 'F', 'Todo ano at? o periodo(Full)'),
(2, 'T', 'Trimestre'),
(3, 'M', 'Momento');
