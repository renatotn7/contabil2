
-- --------------------------------------------------------

--
-- Estrutura da tabela `indicador_trademap_na`
--

CREATE TABLE `indicador_trademap_na` (
  `id_indicador_tradem` int(11) NOT NULL,
  `cvm` int(11) NOT NULL,
  `data` int(11) NOT NULL,
  `indicador` varchar(50) NOT NULL,
  `valor` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
