
-- --------------------------------------------------------

--
-- Estrutura da tabela `periodo`
--

CREATE TABLE `periodo` (
  `id_periodo` int(11) NOT NULL,
  `descricao` longtext NOT NULL,
  `sigla_periodo` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `periodo`
--

INSERT INTO `periodo` (`id_periodo`, `descricao`, `sigla_periodo`) VALUES
(1, 'trimestral', 'T'),
(2, 'Anual', 'A');
