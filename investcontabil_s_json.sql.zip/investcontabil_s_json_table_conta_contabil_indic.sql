
-- --------------------------------------------------------

--
-- Estrutura da tabela `conta_contabil_indic`
--

CREATE TABLE `conta_contabil_indic` (
  `id_conta_contabil_indic` int(11) NOT NULL,
  `id_indicador_relac` int(11) NOT NULL,
  `posicao` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `conta_contabil_indic`
--

INSERT INTO `conta_contabil_indic` (`id_conta_contabil_indic`, `id_indicador_relac`, `posicao`) VALUES
(11, 1, 1),
(12, 2, 1),
(13, 2, 2),
(14, 2, 3);
