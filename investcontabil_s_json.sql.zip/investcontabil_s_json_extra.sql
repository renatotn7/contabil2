
--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `abrangencia`
--
ALTER TABLE `abrangencia`
  ADD PRIMARY KEY (`abrangencia_id`);

--
-- Índices para tabela `calculo`
--
ALTER TABLE `calculo`
  ADD PRIMARY KEY (`id_pk_calculo`),
  ADD KEY `id_calculo` (`id_calculo`),
  ADD KEY `id_indicador` (`id_indicador`),
  ADD KEY `id_expressao` (`id_expressao`);

--
-- Índices para tabela `conta_contabil`
--
ALTER TABLE `conta_contabil`
  ADD PRIMARY KEY (`id_conta_contabil`),
  ADD UNIQUE KEY `conta_contabil` (`conta_contabil`,`id_tipo`,`descricao`,`id_demonstrativo`),
  ADD KEY `FK_ContaContabilTipoDemonstrativo` (`id_tipo`),
  ADD KEY `fk_ref` (`id_refconta`),
  ADD KEY `fk_contapai` (`id_conta_pai`),
  ADD KEY `id_demonstrativo` (`id_demonstrativo`);

--
-- Índices para tabela `conta_contabil_indic`
--
ALTER TABLE `conta_contabil_indic`
  ADD KEY `fk_conta_contabil_indic_indicador_relac` (`id_indicador_relac`) USING BTREE,
  ADD KEY `ind_id_conta_contabil_indic` (`id_conta_contabil_indic`) USING BTREE;

--
-- Índices para tabela `demonstrativo`
--
ALTER TABLE `demonstrativo`
  ADD PRIMARY KEY (`id_demonstrativo`),
  ADD UNIQUE KEY `cvm` (`cvm`,`data`,`versao`,`estado_criacao`,`id_periodo`) USING BTREE,
  ADD KEY `FK_DemonstrativoPeriodo` (`id_periodo`);

--
-- Índices para tabela `empresa`
--
ALTER TABLE `empresa`
  ADD PRIMARY KEY (`cvm`);

--
-- Índices para tabela `expressao`
--
ALTER TABLE `expressao`
  ADD PRIMARY KEY (`id_expressao`);

--
-- Índices para tabela `fund_indicador`
--
ALTER TABLE `fund_indicador`
  ADD PRIMARY KEY (`id_fund_indicador`),
  ADD KEY `FK_fundIndicadorDemonstrativo` (`ID_DEMONSTRATIVO`);

--
-- Índices para tabela `indicador`
--
ALTER TABLE `indicador`
  ADD PRIMARY KEY (`id_indicador`);

--
-- Índices para tabela `indicador_relac`
--
ALTER TABLE `indicador_relac`
  ADD PRIMARY KEY (`id_indicador_relac`),
  ADD KEY `fk_id_indicador_relac_id_indicador` (`id_indicador`) USING BTREE;

--
-- Índices para tabela `indicador_trademap`
--
ALTER TABLE `indicador_trademap`
  ADD PRIMARY KEY (`id_indicador_tradem`),
  ADD UNIQUE KEY `cvm_2` (`cvm`,`data`,`indicador`,`valor`),
  ADD KEY `data` (`data`),
  ADD KEY `indicador` (`indicador`),
  ADD KEY `cvm` (`cvm`);

--
-- Índices para tabela `indicador_trademap_na`
--
ALTER TABLE `indicador_trademap_na`
  ADD PRIMARY KEY (`id_indicador_tradem`),
  ADD UNIQUE KEY `cvm_2` (`cvm`,`data`,`indicador`,`valor`),
  ADD KEY `data` (`data`),
  ADD KEY `indicador` (`indicador`),
  ADD KEY `cvm` (`cvm`);

--
-- Índices para tabela `periodo`
--
ALTER TABLE `periodo`
  ADD PRIMARY KEY (`id_periodo`);

--
-- Índices para tabela `propsta_conf_indic_detalhe`
--
ALTER TABLE `propsta_conf_indic_detalhe`
  ADD PRIMARY KEY (`id_propsta_conf_indic_detalhe`),
  ADD KEY `conta_contabil1` (`conta_contabil1`),
  ADD KEY `FK_pcid_conta_contabil1` (`conta_contabil1`),
  ADD KEY `FK_pcid_conta_contabil2` (`conta_contabil2`),
  ADD KEY `FK_pcid_conta_contabil3` (`conta_contabil3`),
  ADD KEY `FK_pcid_conta_contabil4` (`conta_contabil4`),
  ADD KEY `FK_pcid_conta_contabil5` (`conta_contabil5`),
  ADD KEY `FK_pcid_conta_contabil6` (`conta_contabil6`),
  ADD KEY `FK_pcid_conta_contabil7` (`conta_contabil7`),
  ADD KEY `FK_pcid_conta_contabil8` (`conta_contabil8`),
  ADD KEY `FK_pcid_conta_contabil9` (`conta_contabil9`),
  ADD KEY `FK_pcid_conta_contabil10` (`conta_contabil10`),
  ADD KEY `FK_pcid_pcih` (`id_propsta_conf_indic_header`),
  ADD KEY `FK_pcid_demonstrativo` (`id_demonstrativo`);

--
-- Índices para tabela `propsta_conf_indic_header`
--
ALTER TABLE `propsta_conf_indic_header`
  ADD PRIMARY KEY (`id_propsta_conf_indic_header`),
  ADD KEY `FK_pcih_valor_indicador` (`id_indicador`);

--
-- Índices para tabela `referencial`
--
ALTER TABLE `referencial`
  ADD PRIMARY KEY (`id_referencial`);

--
-- Índices para tabela `tipo_demonstrativo`
--
ALTER TABLE `tipo_demonstrativo`
  ADD PRIMARY KEY (`id_tipo`),
  ADD KEY `abrangencia_id` (`abrangencia_id`);

--
-- Índices para tabela `valor_contabil`
--
ALTER TABLE `valor_contabil`
  ADD PRIMARY KEY (`id_valor_contabil`),
  ADD UNIQUE KEY `id_conta_contabil_2` (`id_conta_contabil`,`id_demonstrativo`) USING BTREE,
  ADD KEY `id_conta_contabil` (`id_conta_contabil`),
  ADD KEY `FK_ValorContabilTipoDemonstrativo` (`id_demonstrativo`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `calculo`
--
ALTER TABLE `calculo`
  MODIFY `id_pk_calculo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT de tabela `conta_contabil`
--
ALTER TABLE `conta_contabil`
  MODIFY `id_conta_contabil` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11311;

--
-- AUTO_INCREMENT de tabela `demonstrativo`
--
ALTER TABLE `demonstrativo`
  MODIFY `id_demonstrativo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1539;

--
-- AUTO_INCREMENT de tabela `expressao`
--
ALTER TABLE `expressao`
  MODIFY `id_expressao` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT de tabela `fund_indicador`
--
ALTER TABLE `fund_indicador`
  MODIFY `id_fund_indicador` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de tabela `indicador_relac`
--
ALTER TABLE `indicador_relac`
  MODIFY `id_indicador_relac` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `indicador_trademap`
--
ALTER TABLE `indicador_trademap`
  MODIFY `id_indicador_tradem` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1128441;

--
-- AUTO_INCREMENT de tabela `indicador_trademap_na`
--
ALTER TABLE `indicador_trademap_na`
  MODIFY `id_indicador_tradem` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `propsta_conf_indic_detalhe`
--
ALTER TABLE `propsta_conf_indic_detalhe`
  MODIFY `id_propsta_conf_indic_detalhe` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=275;

--
-- AUTO_INCREMENT de tabela `propsta_conf_indic_header`
--
ALTER TABLE `propsta_conf_indic_header`
  MODIFY `id_propsta_conf_indic_header` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;

--
-- AUTO_INCREMENT de tabela `referencial`
--
ALTER TABLE `referencial`
  MODIFY `id_referencial` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `valor_contabil`
--
ALTER TABLE `valor_contabil`
  MODIFY `id_valor_contabil` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77942;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `calculo`
--
ALTER TABLE `calculo`
  ADD CONSTRAINT `FK_CalculoExpressao` FOREIGN KEY (`id_expressao`) REFERENCES `expressao` (`id_expressao`),
  ADD CONSTRAINT `FK_CalculoIndicador` FOREIGN KEY (`id_indicador`) REFERENCES `indicador` (`id_indicador`);

--
-- Limitadores para a tabela `conta_contabil`
--
ALTER TABLE `conta_contabil`
  ADD CONSTRAINT `FK_ContaContabilTipoDemonstrativo` FOREIGN KEY (`id_tipo`) REFERENCES `tipo_demonstrativo` (`id_tipo`),
  ADD CONSTRAINT `FK_ContaContabil_Demonstrativo` FOREIGN KEY (`id_demonstrativo`) REFERENCES `demonstrativo` (`id_demonstrativo`),
  ADD CONSTRAINT `fk_contapai` FOREIGN KEY (`id_conta_pai`) REFERENCES `conta_contabil` (`id_conta_contabil`),
  ADD CONSTRAINT `fk_ref` FOREIGN KEY (`id_refconta`) REFERENCES `conta_contabil` (`id_conta_contabil`);

--
-- Limitadores para a tabela `conta_contabil_indic`
--
ALTER TABLE `conta_contabil_indic`
  ADD CONSTRAINT `fk_conta_contabil_indic_indicador_relac` FOREIGN KEY (`id_indicador_relac`) REFERENCES `indicador_relac` (`id_indicador_relac`);

--
-- Limitadores para a tabela `demonstrativo`
--
ALTER TABLE `demonstrativo`
  ADD CONSTRAINT `FK_DemonstrativoEmpresa` FOREIGN KEY (`cvm`) REFERENCES `empresa` (`cvm`),
  ADD CONSTRAINT `FK_DemonstrativoPeriodo` FOREIGN KEY (`id_periodo`) REFERENCES `periodo` (`id_periodo`);

--
-- Limitadores para a tabela `fund_indicador`
--
ALTER TABLE `fund_indicador`
  ADD CONSTRAINT `FK_fundIndicadorDemonstrativo` FOREIGN KEY (`ID_DEMONSTRATIVO`) REFERENCES `demonstrativo` (`id_demonstrativo`);

--
-- Limitadores para a tabela `indicador_relac`
--
ALTER TABLE `indicador_relac`
  ADD CONSTRAINT `fk_id_indicador_relac_id_indicador` FOREIGN KEY (`id_indicador`) REFERENCES `indicador` (`id_indicador`);

--
-- Limitadores para a tabela `propsta_conf_indic_detalhe`
--
ALTER TABLE `propsta_conf_indic_detalhe`
  ADD CONSTRAINT `FK_pcid_conta_contabil1` FOREIGN KEY (`conta_contabil1`) REFERENCES `conta_contabil` (`id_conta_contabil`),
  ADD CONSTRAINT `FK_pcid_conta_contabil10` FOREIGN KEY (`conta_contabil10`) REFERENCES `conta_contabil` (`id_conta_contabil`),
  ADD CONSTRAINT `FK_pcid_conta_contabil2` FOREIGN KEY (`conta_contabil2`) REFERENCES `conta_contabil` (`id_conta_contabil`),
  ADD CONSTRAINT `FK_pcid_conta_contabil3` FOREIGN KEY (`conta_contabil3`) REFERENCES `conta_contabil` (`id_conta_contabil`),
  ADD CONSTRAINT `FK_pcid_conta_contabil4` FOREIGN KEY (`conta_contabil4`) REFERENCES `conta_contabil` (`id_conta_contabil`),
  ADD CONSTRAINT `FK_pcid_conta_contabil5` FOREIGN KEY (`conta_contabil5`) REFERENCES `conta_contabil` (`id_conta_contabil`),
  ADD CONSTRAINT `FK_pcid_conta_contabil6` FOREIGN KEY (`conta_contabil6`) REFERENCES `conta_contabil` (`id_conta_contabil`),
  ADD CONSTRAINT `FK_pcid_conta_contabil7` FOREIGN KEY (`conta_contabil7`) REFERENCES `conta_contabil` (`id_conta_contabil`),
  ADD CONSTRAINT `FK_pcid_conta_contabil8` FOREIGN KEY (`conta_contabil8`) REFERENCES `conta_contabil` (`id_conta_contabil`),
  ADD CONSTRAINT `FK_pcid_conta_contabil9` FOREIGN KEY (`conta_contabil9`) REFERENCES `conta_contabil` (`id_conta_contabil`),
  ADD CONSTRAINT `FK_pcid_demonstrativo` FOREIGN KEY (`id_demonstrativo`) REFERENCES `demonstrativo` (`id_demonstrativo`),
  ADD CONSTRAINT `FK_pcid_pcih` FOREIGN KEY (`id_propsta_conf_indic_header`) REFERENCES `propsta_conf_indic_header` (`id_propsta_conf_indic_header`);

--
-- Limitadores para a tabela `propsta_conf_indic_header`
--
ALTER TABLE `propsta_conf_indic_header`
  ADD CONSTRAINT `FK_pcih_valor_indicador` FOREIGN KEY (`id_indicador`) REFERENCES `indicador` (`id_indicador`);

--
-- Limitadores para a tabela `tipo_demonstrativo`
--
ALTER TABLE `tipo_demonstrativo`
  ADD CONSTRAINT `FK_TipoDemonstrativoAbrangencia` FOREIGN KEY (`abrangencia_id`) REFERENCES `abrangencia` (`abrangencia_id`),
  ADD CONSTRAINT `tipo_demonstrativo_ibfk_1` FOREIGN KEY (`abrangencia_id`) REFERENCES `abrangencia` (`abrangencia_id`);

--
-- Limitadores para a tabela `valor_contabil`
--
ALTER TABLE `valor_contabil`
  ADD CONSTRAINT `FK_ValorContabilTipoDemonstrativo` FOREIGN KEY (`id_demonstrativo`) REFERENCES `demonstrativo` (`id_demonstrativo`),
  ADD CONSTRAINT `valor_contabil_ibfk_1` FOREIGN KEY (`id_conta_contabil`) REFERENCES `conta_contabil` (`id_conta_contabil`);
