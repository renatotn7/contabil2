
-- --------------------------------------------------------

--
-- Estrutura da tabela `referencial`
--

CREATE TABLE `referencial` (
  `id_referencial` int(11) NOT NULL,
  `cvm_ref` int(11) NOT NULL,
  `data_ref` int(11) NOT NULL,
  `versao_ref` int(11) NOT NULL,
  `id_periodo_ref` int(11) NOT NULL,
  `cvm` int(11) NOT NULL,
  `data` int(11) NOT NULL,
  `versao` int(11) NOT NULL,
  `id_periodo` int(11) NOT NULL,
  `estado_alteracao` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `referencial`
--

INSERT INTO `referencial` (`id_referencial`, `cvm_ref`, `data_ref`, `versao_ref`, `id_periodo_ref`, `cvm`, `data`, `versao`, `id_periodo`, `estado_alteracao`) VALUES
(1, 5258, 201112, 1, 2, 1, 5258, 201212, 2, 'W');
