
-- --------------------------------------------------------

--
-- Estrutura da tabela `indicador_relac`
--

CREATE TABLE `indicador_relac` (
  `id_indicador_relac` int(11) NOT NULL,
  `id_indicador` int(11) NOT NULL,
  `numero` int(4) NOT NULL,
  `expressao` varchar(50) NOT NULL,
  `colunas` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `indicador_relac`
--

INSERT INTO `indicador_relac` (`id_indicador_relac`, `id_indicador`, `numero`, `expressao`, `colunas`) VALUES
(1, 2, 1, '::1', 1),
(2, 2, 2, '::1+::2+::3', 3);
