
-- --------------------------------------------------------

--
-- Estrutura da tabela `calculo`
--

CREATE TABLE `calculo` (
  `id_calculo` int(11) NOT NULL,
  `id_indicador` int(11) NOT NULL,
  `id_expressao` int(11) NOT NULL,
  `preferencia` int(3) NOT NULL,
  `posicao` int(2) NOT NULL,
  `id_pk_calculo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `calculo`
--

INSERT INTO `calculo` (`id_calculo`, `id_indicador`, `id_expressao`, `preferencia`, `posicao`, `id_pk_calculo`) VALUES
(1, 2, 1, 1, 1, 53),
(2, 5, 2, 2, 1, 54),
(3, 5, 2, 2, 2, 55),
(2, 5, 9, 3, 1, 56),
(4, 5, 9, 3, 2, 57),
(5, 5, 9, 3, 3, 58),
(2, 5, 8, 3, 1, 59),
(5, 5, 8, 3, 2, 60),
(4, 5, 8, 3, 3, 61),
(6, 11, 2, 2, 1, 62),
(7, 11, 2, 2, 2, 63),
(8, 13, 1, 1, 1, 64),
(9, 5, 2, 2, 2, 65),
(10, 2, 7, 3, 1, 66),
(11, 2, 7, 3, 2, 67),
(12, 2, 7, 3, 3, 68),
(6, 11, 7, 3, 1, 69),
(13, 11, 7, 3, 2, 70),
(14, 11, 7, 3, 3, 71),
(15, 11, 7, 3, 1, 72),
(16, 11, 7, 3, 2, 73),
(7, 11, 7, 3, 3, 74),
(17, 13, 2, 2, 1, 75),
(18, 13, 2, 2, 2, 76);
