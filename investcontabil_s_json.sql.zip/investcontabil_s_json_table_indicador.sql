
-- --------------------------------------------------------

--
-- Estrutura da tabela `indicador`
--

CREATE TABLE `indicador` (
  `id_indicador` int(11) NOT NULL,
  `nome_indicador` varchar(100) NOT NULL,
  `descricao` varchar(255) NOT NULL,
  `numpref` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `indicador`
--

INSERT INTO `indicador` (`id_indicador`, `nome_indicador`, `descricao`, `numpref`) VALUES
(1, 'Patrimônio Líquido', 'Patrimônio Líquido Consolidado', 1),
(2, 'Pat_Liq', 'Pat_Liq', 1),
(4, 'Receita_Liq', '', 0),
(5, 'EBITDA', '', 2),
(6, 'Res_Fin', '', 0),
(7, 'Lucro_Liq', '', 2),
(8, 'Mrg_Liq', '', 0),
(9, 'ROE', '', 0),
(10, 'Caixa', '', 0),
(11, 'Divida', '', 3),
(12, 'D_L_div_EBITDA', '', 0),
(13, 'FCO', '', 1),
(14, 'CAPEX', '', 0),
(15, 'FCF', '', 0),
(16, 'FCL_CAPEX', '', 0),
(17, 'Prov', '', 0),
(18, 'Payout', '', 0);
