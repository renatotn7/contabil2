
-- --------------------------------------------------------

--
-- Estrutura da tabela `tipo_demonstrativo`
--

CREATE TABLE `tipo_demonstrativo` (
  `id_tipo` int(10) NOT NULL,
  `sigla_tipo` varchar(30) NOT NULL,
  `descricao_tipo` varchar(256) NOT NULL,
  `abrangencia_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tipo_demonstrativo`
--

INSERT INTO `tipo_demonstrativo` (`id_tipo`, `sigla_tipo`, `descricao_tipo`, `abrangencia_id`) VALUES
(1, 'DRA', 'Resultado Abrangente', 2),
(2, 'DR', 'Resultados', 2),
(3, 'BPA', 'Ativo', 3),
(4, 'BPP', 'Passivo', 3),
(5, 'FC', 'Fluxo de caixa', 1),
(6, 'DVA', 'Valor adicionado', 2);
