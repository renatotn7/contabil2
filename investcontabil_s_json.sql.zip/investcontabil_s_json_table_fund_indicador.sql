
-- --------------------------------------------------------

--
-- Estrutura da tabela `fund_indicador`
--

CREATE TABLE `fund_indicador` (
  `id_fund_indicador` int(11) NOT NULL,
  `ID_DEMONSTRATIVO` int(11) NOT NULL,
  `Pat_Liq` double DEFAULT NULL,
  `Receita_Liq` double DEFAULT NULL,
  `EBITDA` double DEFAULT NULL,
  `Res_Fin` double DEFAULT NULL,
  `Lucro_Liq` double DEFAULT NULL,
  `Mrg_Liq` double DEFAULT NULL,
  `ROE` double DEFAULT NULL,
  `Caixa` double DEFAULT NULL,
  `Divida` double DEFAULT NULL,
  `D_L_div_EBITDA` double DEFAULT NULL,
  `FCO` double DEFAULT NULL,
  `CAPEX` double DEFAULT NULL,
  `FCF` double DEFAULT NULL,
  `FCL_CAPEX` double DEFAULT NULL,
  `Prov` double DEFAULT NULL,
  `Payout` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `fund_indicador`
--

INSERT INTO `fund_indicador` (`id_fund_indicador`, `ID_DEMONSTRATIVO`, `Pat_Liq`, `Receita_Liq`, `EBITDA`, `Res_Fin`, `Lucro_Liq`, `Mrg_Liq`, `ROE`, `Caixa`, `Divida`, `D_L_div_EBITDA`, `FCO`, `CAPEX`, `FCF`, `FCL_CAPEX`, `Prov`, `Payout`) VALUES
(1, 75, 2657, 8897, 729, -65, 340, 0.04, 0.13, 266, 296, 0, 502, -385, -129, 117, 121, 0.36),
(2, 81, 2936, 11257, 980, -110, 451, 0.04, 0.15, 277, 414, 0.1, 556, -490, -56, 66, 195, 0.43),
(3, 87, 3250, 13213, 1131, -106, 513, 0.04, 0.16, 265, 611, 0.3, 629, -640, -1, -11, 203, 0.4),
(4, 93, 3535, 14801, 1136, -83, 509, 0.03, 0.14, 242, 843, 0.5, 683, -703, -3, -20, 210, 0.41),
(5, 1020, 2311, 6145, 1198, -105, 579, 0.09, 0.25, 738, 1903, 1, 772, -571, -298, 201, 232, 0.4),
(6, 1014, 2637, 6452, 1287, -103, 625, 0.1, 0.24, 895, 1876, 0.8, 914, -477, -279, 437, 250, 0.4),
(7, 1008, 3223, 7444, 1416, -83, 733, 0.1, 0.23, 1142, 1871, 0.5, 846, -550, -129, 296, 293, 0.4),
(8, 1002, 3955, 8427, 1739, -54, 1020, 0.12, 0.26, 1384, 1924, 0.3, 811, -610, -318, 201, 256, 0.25),
(9, 658, 6156, 9760, 1477, 145, 1166, 0.12, 0.19, 4434, 5152, 0.5, 982, -507, -158, 475, 593, 0.51),
(10, 641, 6043, 9367, 1407, 216, 1128, 0.12, 0.19, 4764, 4400, 0, 1957, -363, -1064, 1594, 579, 0.51),
(11, 627, 6838, 9524, 1466, 58, 1141, 0.12, 0.17, 4574, 4056, 0, 1107, -266, -1153, 841, 607, 0.53),
(12, 611, 7853, 11970, 1824, -9, 1344, 0.11, 0.17, 3530, 3772, 0.1, 1300, -429, -1446, 871, 704, 0.52),
(13, 594, 4377, 1542, 1540, -468, 909, 0.59, 0.21, 215, 3673, 2.2, 1685, -8, -1648, 1677, 825, 0.91),
(14, 600, 4308, 1391, 1374, -401, 862, 0.62, 0.2, 364, 3290, 2.1, 1613, -7, -1460, 1606, 784, 0.91),
(15, 606, 4348, 1077, 930, -223, 648, 0.6, 0.15, 627, 3005, 2.6, 1473, -16, -1188, 1457, 593, 0.92),
(16, 615, 4572, 1635, 1436, -211, 1071, 0.66, 0.23, 819, 3300, 1.7, 1197, -36, -996, 1161, 960, 0.9);
