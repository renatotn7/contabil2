
-- --------------------------------------------------------

--
-- Estrutura da tabela `expressao`
--

CREATE TABLE `expressao` (
  `id_expressao` int(11) NOT NULL,
  `expressao` varchar(70) NOT NULL,
  `num_colunas` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `expressao`
--

INSERT INTO `expressao` (`id_expressao`, `expressao`, `num_colunas`) VALUES
(1, '::1', 1),
(2, '::1+::2', 2),
(3, '::1-::2', 2),
(4, '-::1+::2', 2),
(5, '-::1-::2', 2),
(6, '-::1', 1),
(7, '::1+::2+::3', 3),
(8, '::1+::2-::3', 3),
(9, '::1-::2+::3', 3),
(10, '-::1+::2+::3', 3),
(11, '-::1-::2+::3', 3),
(12, '-::1+::2-::3', 3),
(13, '-::1-::2-::3', 3),
(14, '::1-::2-::3', 3);
